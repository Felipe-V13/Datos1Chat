public class prueba {
    public static void main(String[] args) {

       p ersona 1= new persona();
            string cedula;
            persona 1
       public void presentarse(){

        }
    }
}
